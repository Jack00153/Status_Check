Example of using an automated script to monitor the status of files, depending on the size of the file, if a large file is detected, then records will be automatically created with information depending on the file size has been exceeded.


programs used:

- Postgres 14.7
- TimescaleDB 2.10.3
- Workbench 
