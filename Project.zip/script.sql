CREATE OR REPLACE PROCEDURE Status_Check (job_id int, config jsonb)
LANGUAGE PLPGSQL
AS $total$
DECLARE
  total integer;
  BEGIN
  RAISE NOTICE 'Executing action % with config %', job_id, config;
IF EXISTS (
      SELECT FROM public.meta_files_table WHERE file_size <= '500')  
      THEN
      INSERT INTO meta_errors_table (file_id, error_file, today_date, file_size)
      VALUES ('file_1', 'ok', CURRENT_DATE, 'less or equal to 500');
END IF;
IF EXISTS (
      SELECT FROM public.meta_files_table WHERE file_size > '500')  
      THEN
      INSERT INTO meta_errors_table (file_id, error_file, today_date, file_size)
      VALUES ('file_2', '!!!', CURRENT_DATE, 'more than 500');
END IF;
IF EXISTS (
      SELECT FROM public.meta_files_table WHERE file_size = '0' OR file_size = NULL)  
      THEN
      INSERT INTO meta_errors_table (file_id, error_file, today_date, file_size)
      VALUES ('file_3', 'WARNING EMPTY FILE', CURRENT_DATE, 'equal to 0 or nothing');
END IF;
END
$total$;

COMMIT;


