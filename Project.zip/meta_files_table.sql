DROP TABLE IF EXISTS meta_files_table CASCADE;

CREATE TABLE meta_files_table
(
   file_name             varchar(50),
   file_size             bigint,
   file_created          date,
   file_library          varchar(10),
   file_class            varchar(32),
   file_period           varchar(10)
);




COMMENT ON TABLE meta_files_table IS 'file registry';
COMMENT ON COLUMN meta_files_table.file_name IS 'file name';
COMMENT ON COLUMN meta_files_table.file_size IS 'file size';
COMMENT ON COLUMN meta_files_table.file_created IS 'creation date';
COMMENT ON COLUMN meta_files_table.file_library IS 'library';
COMMENT ON COLUMN meta_files_table.file_class IS 'the class file belongs to';
COMMENT ON COLUMN meta_files_table.file_period IS 'the period covered by the data';





GRANT SELECT ON meta_files_table TO test;
GRANT UPDATE, INSERT, SELECT ON meta_files_table TO user_1;
GRANT REFERENCES, SELECT ON meta_files_table TO user_2;

COMMIT;


----------------------------------------------------------------------------------------------------------------


INSERT INTO meta_files_table (file_name, file_size, file_library, file_created, file_class, file_period)
VALUES ('task_1', '600', 'lib_1', CURRENT_DATE, 'class_task_1', CURRENT_DATE);

INSERT INTO meta_files_table (file_name, file_size, file_library, file_created, file_class, file_period)
VALUES ('task_2', '0', 'lib_1', CURRENT_DATE, 'class_task_2', CURRENT_DATE);

INSERT INTO meta_files_table (file_name, file_size, file_library, file_created, file_class, file_period)
VALUES ('task_3', '300', 'lib_2', CURRENT_DATE, 'class_task_3', CURRENT_DATE);

INSERT INTO meta_files_table (file_name, file_size, file_library, file_created, file_class, file_period)
VALUES ('task_4', '500', 'lib_2', CURRENT_DATE, 'class_task_4', CURRENT_DATE);

