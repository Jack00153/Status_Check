DROP TABLE IF EXISTS meta_errors_table CASCADE;

CREATE TABLE meta_errors_table
(
   file_id         varchar(30),
   error_file        varchar(30),
   today_date        date,
   file_size         varchar(30)
);


COMMENT ON COLUMN meta_errors_table.file_id IS 'process name.';
COMMENT ON COLUMN meta_errors_table.error_file IS 'file name.';
COMMENT ON COLUMN meta_errors_table.today_date IS 'the date the status occurred.';
COMMENT ON COLUMN meta_errors_table.file_size IS 'information about size.';



GRANT SELECT ON meta_errors_table TO test;
GRANT SELECT ON meta_errors_table TO user_1;
GRANT SELECT ON meta_errors_table TO user_2;
GRANT INSERT, REFERENCES, TRIGGER, DELETE, UPDATE, TRUNCATE, SELECT ON meta_errors_table TO postgres;


COMMIT;

