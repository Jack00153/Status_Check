SELECT add_job('Status_Check','1 day', scheduled => false);

SELECT alter_job(1012,'1 day', next_start => '2023-05-01 06:00:00.0+00', scheduled => true);

SELECT alter_job(1012, scheduled => false);

SELECT delete_job(1012);

